abstract class EnergySource {
    int sourceId;
    String sourceName;
    double energyGenerated;

    EnergySource(int id, String name, double energy) {
        sourceId = id;
        sourceName = name;
        energyGenerated = energy;
    }

    abstract double calculateEfficiency();

    void displayDetails() {
        System.out.println("Source ID: " + sourceId);
        System.out.println("Source Name: " + sourceName);
        System.out.println("Energy Generated: " + energyGenerated + " kWh");
        System.out.println("Efficiency: " + calculateEfficiency() + "%");
    }
}

class SolarEnergy extends EnergySource {
    SolarEnergy(int id, String name, double energy) {
        super(id, name, energy);
    }

    double calculateEfficiency() {
        return (energyGenerated / 5000) * 100;
    }
}

class WindEnergy extends EnergySource {
    WindEnergy(int id, String name, double energy) {
        super(id, name, energy);
    }

    double calculateEfficiency() {
        return (energyGenerated / 8000) * 100;
    }
}

public class EnergyDemo {
    public static void main(String[] args) {
        EnergySource ref;

        SolarEnergy s = new SolarEnergy(201, "Rooftop Solar Panel", 3600);
        WindEnergy w = new WindEnergy(202, "Suzlon Wind Turbine", 6000);

        System.out.println("--- Solar Energy Details ---");
        ref = s;
        ref.displayDetails();

        System.out.println("\n--- Wind Energy Details ---");
        ref = w;
        ref.displayDetails();
    }
}
