class BusReservation {
    int availableSeats = 1;

    void bookWithoutSync(String name) {
        System.out.println(name + " is trying to book the seat...");
        if (availableSeats > 0) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
            availableSeats--;
            System.out.println("Seat booked successfully for " + name);
        } else {
            System.out.println("Sorry " + name + ", seat already booked!");
        }
    }

    synchronized void bookWithSync(String name) {
        System.out.println(name + " is trying to book the seat...");
        if (availableSeats > 0) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
            availableSeats--;
            System.out.println("Seat booked successfully for " + name);
        } else {
            System.out.println("Sorry " + name + ", seat already booked!");
        }
    }
}

class CustomerThread extends Thread {
    BusReservation bus;
    String custName;
    boolean useSync;

    CustomerThread(BusReservation b, String name, boolean sync) {
        bus = b;
        custName = name;
        useSync = sync;
    }

    public void run() {
        if (useSync)
            bus.bookWithSync(custName);
        else
            bus.bookWithoutSync(custName);
    }
}

public class BusDemo {
    public static void main(String[] args) throws Exception {
        System.out.println("--- Without Synchronization (Race Condition) ---");
        BusReservation b1 = new BusReservation();
        CustomerThread t1 = new CustomerThread(b1, "Customer 1", false);
        CustomerThread t2 = new CustomerThread(b1, "Customer 2", false);
        t1.start();
        t2.start();
        t1.join();
        t2.join();

        System.out.println("\n--- With Synchronization (Thread Safe) ---");
        BusReservation b2 = new BusReservation();
        CustomerThread t3 = new CustomerThread(b2, "Customer 1", true);
        CustomerThread t4 = new CustomerThread(b2, "Customer 2", true);
        t3.start();
        t4.start();
        t3.join();
        t4.join();
    }
}
