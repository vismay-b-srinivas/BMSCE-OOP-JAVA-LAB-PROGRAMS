import java.util.Scanner;

public class EmailOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter email address: ");
        String rawEmail = sc.nextLine();

        String email = rawEmail.trim();
        System.out.println("Trimmed email: " + email);
        System.out.println("Length: " + email.length());

        int atIndex = email.indexOf('@');
        String username = email.substring(0, atIndex);
        String domain = email.substring(atIndex + 1);
        System.out.println("Username: " + username);
        System.out.println("Domain: " + domain);

        if (domain.equalsIgnoreCase("bmsce.ac.in")) {
            System.out.println("Belongs to the institution.");
        } else {
            System.out.println("Does not belong to the institution.");
        }

        String lowerEmail = email.toLowerCase();
        System.out.println("Lowercase email: " + lowerEmail);

        System.out.print("\nEnter a prefix to check: ");
        String prefix = sc.nextLine();
        System.out.println("Starts with prefix? " + lowerEmail.startsWith(prefix));
        System.out.println("Ends with 'bmsce.ac.in'? " + lowerEmail.endsWith("bmsce.ac.in"));

        String updatedEmail = lowerEmail.replace("bmsce.ac.in", "cse.bmsce.ac.in");
        System.out.println("Updated email: " + updatedEmail);
        System.out.println("Contains 'cs'? " + lowerEmail.contains("cs"));

        System.out.print("\nEnter second email to compare: ");
        String secondEmail = sc.nextLine();
        System.out.println("10. Emails are identical? " + email.equalsIgnoreCase(secondEmail));
    }
}
