import transaction.Account;
import reports.ReportGenerator;
import java.util.Scanner;

public class BankApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Account Number: ");
        int no = sc.nextInt();
        System.out.print("Enter Initial Balance: ");
        double bal = sc.nextDouble();

        Account acc = new Account(no, bal);
        ReportGenerator rep = new ReportGenerator();

        System.out.print("Enter amount to deposit: ");
        double dep = sc.nextDouble();
        acc.deposit(dep);

        System.out.print("Enter amount to withdraw: ");
        double wd = sc.nextDouble();
        acc.withdraw(wd);

        rep.generateReport(acc, "Deposit & Withdrawal");
    }
}
