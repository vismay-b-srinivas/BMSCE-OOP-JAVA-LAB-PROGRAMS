package reports;
import transaction.Account;

public class ReportGenerator {
    public void generateReport(Account acc, String lastTxn) {
        System.out.println("\n--- Transaction Report ---");
        System.out.println("Account Number: " + acc.accNo);
        System.out.println("Last Operation: " + lastTxn);
        System.out.println("Current Balance: Rs. " + acc.balance);
    }
}
