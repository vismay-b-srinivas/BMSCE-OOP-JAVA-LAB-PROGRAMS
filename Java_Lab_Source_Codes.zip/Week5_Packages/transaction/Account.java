package transaction;

public class Account {
    public int accNo;
    public double balance;

    public Account(int no, double bal) {
        accNo = no;
        balance = bal;
    }

    public void deposit(double amt) {
        balance = balance + amt;
        System.out.println("Deposited: Rs. " + amt);
    }

    public void withdraw(double amt) {
        if (amt <= balance) {
            balance = balance - amt;
            System.out.println("Withdrawn: Rs. " + amt);
        } else {
            System.out.println("Insufficient balance!");
        }
    }
}
