import java.util.Scanner;

class Book {
    int bookId;
    String title;
    String author;
    double price;
    static int count = 0;

    Book(int id, String t, String a, double p) {
        bookId = id;
        title = t;
        author = a;
        price = p;
        count++;
    }

    void display() {
        System.out.println("ID: " + bookId + ", Title: " + title + ", Author: " + author + ", Price: " + price);
    }

    boolean search(int id) {
        if (bookId == id)
            return true;
        else
            return false;
    }

    boolean search(String t) {
        if (title.equalsIgnoreCase(t))
            return true;
        else
            return false;
    }

    Book compareCost(Book b) {
        if (this.price > b.price)
            return this;
        else
            return b;
    }
}

public class BookMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Book b1 = new Book(101, "Java Programming", "Herbert Schildt", 650.0);
        Book b2 = new Book(102, "Data Structures", "Seymour Lipschutz", 480.0);
        Book b3 = new Book(103, "Operating Systems", "Galvin", 720.0);

        Book arr[] = {b1, b2, b3};

        System.out.println("--- Book List ---");
        for (int i = 0; i < arr.length; i++) {
            arr[i].display();
        }
        System.out.println("Total books created: " + Book.count);

        System.out.print("\nEnter Book ID to search: ");
        int sid = sc.nextInt();
        sc.nextLine();
        boolean foundId = false;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].search(sid)) {
                System.out.println("Book found by ID:");
                arr[i].display();
                foundId = true;
            }
        }
        if (!foundId)
            System.out.println("Book ID not found.");

        System.out.print("\nEnter Title to search: ");
        String stitle = sc.nextLine();
        boolean foundTitle = false;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].search(stitle)) {
                System.out.println("Book found by Title:");
                arr[i].display();
                foundTitle = true;
            }
        }
        if (!foundTitle)
            System.out.println("Book Title not found.");

        System.out.println("\nComparing Book 1 and Book 3:");
        Book costlier = b1.compareCost(b3);
        System.out.println("Costlier book is: " + costlier.title + " (Rs. " + costlier.price + ")");
    }
}
