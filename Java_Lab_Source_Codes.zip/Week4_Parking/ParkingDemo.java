import java.util.Scanner;

interface ParkingCharge {
    double calculateCharge();
    void displayParkingDetails();
}

class VehicleParking {
    String vehicleNumber;
    String vehicleType;
    int parkingHours;

    VehicleParking(String num, String type, int hrs) {
        vehicleNumber = num;
        vehicleType = type;
        parkingHours = hrs;
    }
}

class TwoWheeler extends VehicleParking implements ParkingCharge {
    TwoWheeler(String num, int hrs) {
        super(num, "Two Wheeler", hrs);
    }

    public double calculateCharge() {
        if (parkingHours <= 2)
            return parkingHours * 20;
        else
            return (2 * 20) + (parkingHours - 2) * 10;
    }

    public void displayParkingDetails() {
        System.out.println("Vehicle Number: " + vehicleNumber);
        System.out.println("Vehicle Type: " + vehicleType);
        System.out.println("Parking Hours: " + parkingHours);
        System.out.println("Total Charge: Rs. " + calculateCharge());
    }
}

class FourWheeler extends VehicleParking implements ParkingCharge {
    FourWheeler(String num, int hrs) {
        super(num, "Four Wheeler", hrs);
    }

    public double calculateCharge() {
        if (parkingHours <= 2)
            return parkingHours * 50;
        else
            return (2 * 50) + (parkingHours - 2) * 30;
    }

    public void displayParkingDetails() {
        System.out.println("Vehicle Number: " + vehicleNumber);
        System.out.println("Vehicle Type: " + vehicleType);
        System.out.println("Parking Hours: " + parkingHours);
        System.out.println("Total Charge: Rs. " + calculateCharge());
    }
}

public class ParkingDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ParkingCharge ref;

        System.out.print("Enter Two Wheeler Number: ");
        String twNum = sc.nextLine();
        System.out.print("Enter Parking Hours: ");
        int twHrs = sc.nextInt();
        sc.nextLine();

        System.out.print("\nEnter Four Wheeler Number: ");
        String fwNum = sc.nextLine();
        System.out.print("Enter Parking Hours: ");
        int fwHrs = sc.nextInt();

        System.out.println("\n--- Two Wheeler Parking ---");
        ref = new TwoWheeler(twNum, twHrs);
        ref.displayParkingDetails();

        System.out.println("\n--- Four Wheeler Parking ---");
        ref = new FourWheeler(fwNum, fwHrs);
        ref.displayParkingDetails();
    }
}
