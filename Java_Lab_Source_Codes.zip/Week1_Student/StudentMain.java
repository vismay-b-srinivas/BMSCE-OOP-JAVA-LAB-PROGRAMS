import java.util.Scanner;

class Student {
    String usn;
    String name;

    void accept(Scanner sc) {
        System.out.print("Enter USN: ");
        usn = sc.nextLine();
        System.out.print("Enter Name: ");
        name = sc.nextLine();
    }

    void display() {
        System.out.println("USN: " + usn + "  Name: " + name);
    }
}

public class StudentMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine();

        Student s[] = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details of student " + (i + 1) + ":");
            s[i] = new Student();
            s[i].accept(sc);
        }

        System.out.println("\n--- Student Details ---");
        for (int i = 0; i < n; i++) {
            s[i].display();
        }
    }
}
