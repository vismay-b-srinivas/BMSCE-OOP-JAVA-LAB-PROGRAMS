import java.util.Scanner;
import java.util.InputMismatchException;

class SeatAlreadyBookedException extends Exception {
    SeatAlreadyBookedException(String msg) {
        super(msg);
    }
}

class Reservation {
    boolean seats[] = new boolean[31]; // seats 1 to 30

    void reserveSeat(int seatNo) throws SeatAlreadyBookedException {
        if (seatNo < 1 || seatNo > 30) {
            throw new ArrayIndexOutOfBoundsException("Invalid seat number! Choose between 1 and 30.");
        }
        if (seats[seatNo] == true) {
            throw new SeatAlreadyBookedException("Seat " + seatNo + " is already booked!");
        }
        seats[seatNo] = true;
        System.out.println("Seat " + seatNo + " reserved successfully.");
    }
}

public class RailwayMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Reservation res = new Reservation();

        System.out.print("Enter number of booking attempts: ");
        int n = sc.nextInt();

        for (int i = 1; i <= n; i++) {
            System.out.print("\nAttempt " + i + " - Enter seat number (1-30): ");
            try {
                int s = sc.nextInt();
                res.reserveSeat(s);
            } catch (InputMismatchException e) {
                System.out.println("Error: Invalid input! Please enter a valid integer.");
                sc.nextLine();
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (SeatAlreadyBookedException e) {
                System.out.println("Booking Failed: " + e.getMessage());
            } finally {
                System.out.println("Transaction attempt " + i + " completed.");
            }
        }
    }
}
