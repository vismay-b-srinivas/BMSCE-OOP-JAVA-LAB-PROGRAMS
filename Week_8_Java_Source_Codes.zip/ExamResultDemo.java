import java.util.Scanner;

enum Result {
    PASS, FAIL, ABSENT
}

class Student {
    String usn;
    String name;
    Integer marks;
    Result status;

    void accept(Scanner sc) {
        System.out.print("Enter USN: ");
        usn = sc.nextLine();
        System.out.print("Enter Name: ");
        name = sc.nextLine();
        System.out.print("Enter Marks (-1 for Absent): ");
        int m = sc.nextInt();
        sc.nextLine();
        marks = m;
    }

    void calculateResult() {
        int m = marks;
        if (m == -1) {
            status = Result.ABSENT;
        } else if (m >= 40) {
            status = Result.PASS;
        } else {
            status = Result.FAIL;
        }
    }

    void display() {
        System.out.println("USN: " + usn + " | Name: " + name + " | Marks: " + marks + " | Result: " + status);
    }
}

public class ExamResultDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine();

        Student s[] = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details of student " + (i + 1) + ":");
            s[i] = new Student();
            s[i].accept(sc);
            s[i].calculateResult();
        }

        System.out.println("\n--- Examination Results ---");
        for (int i = 0; i < n; i++) {
            s[i].display();
        }
    }
}
