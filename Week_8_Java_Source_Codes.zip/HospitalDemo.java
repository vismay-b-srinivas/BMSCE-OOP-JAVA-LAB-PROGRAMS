import java.io.*;

class PatientRecord<T1, T2> {
    T1 patientID;
    T2 doctorAssigned;

    void addRecord(T1 patientID, T2 doctorAssigned) {
        this.patientID = patientID;
        this.doctorAssigned = doctorAssigned;
    }

    void displayRecord() {
        System.out.println("Patient ID: " + patientID + " | Doctor Assigned: " + doctorAssigned);
    }
}

public class HospitalDemo {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        PatientRecord<String, String> p1 = new PatientRecord<String, String>();
        PatientRecord<String, String> p2 = new PatientRecord<String, String>();

        System.out.print("Enter Alphanumeric Patient ID: ");
        String id1 = br.readLine();
        System.out.print("Enter Doctor Name: ");
        String doc1 = br.readLine();
        p1.addRecord(id1, doc1);

        System.out.print("\nEnter Numeric Patient ID: ");
        String id2 = br.readLine();
        System.out.print("Enter Doctor Name: ");
        String doc2 = br.readLine();
        p2.addRecord(id2, doc2);

        System.out.println("\n--- Hospital Patient Records ---");
        p1.displayRecord();
        p2.displayRecord();
    }
}
